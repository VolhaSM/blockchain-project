package blockchain.project.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class WalletController {
}
