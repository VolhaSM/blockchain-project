package blockchain.project;

import blockchain.project.web.ApplicationConfiguration;
import org.springframework.boot.SpringApplication;

public class ApplicationRunner {


}
