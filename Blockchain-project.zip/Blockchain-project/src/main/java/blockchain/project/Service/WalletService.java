package blockchain.project.Service;

import org.springframework.stereotype.Service;

@Service
public class WalletService {
}
