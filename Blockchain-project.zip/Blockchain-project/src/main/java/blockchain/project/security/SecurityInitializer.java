package blockchain.project.security;

public class SecurityInitializer {
}
